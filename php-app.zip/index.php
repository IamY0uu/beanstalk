<?php
echo "<h1>Welcome to my PHP App on AWS Elastic Beanstalk!</h1>";
echo "<p>Deployed using Elastic Beanstalk Environment.</p>";
?>